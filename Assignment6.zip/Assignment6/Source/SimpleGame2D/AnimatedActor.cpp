// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"
#include "AnimatedActor.h"


// Sets default values
AAnimatedActor::AAnimatedActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//UPaperSpriteComponent* spriteComponent = CreateDefaultSubobject<UPaperSpriteComponent>(TEXT("Sprite"));
	//spriteComponent->AttachTo(RootComponent);
	//spriteComponent->RelativeLocation = FVector(0.0f, 0.0f, 0.0f);
	//spriteComponent->SetSprite(ConstructorHelpers::FObjectFinder<UPaperFlipbook>(TEXT("/Game/Sprites/enemy1_Sprite")).Object);

	UPaperFlipbookComponent* flipbookComponent = (UPaperFlipbookComponent*)CreateDefaultSubobject<UPaperFlipbookComponent>(TEXT("Flipbook"));
	flipbookComponent->AttachTo(RootComponent);
	flipbookComponent->SetFlipbook(ConstructorHelpers::FObjectFinder<UPaperFlipbook>(TEXT("/Game/Sprites/bladesFlipbook")).Object);
	flipbookComponent->RelativeLocation = FVector(0.0, 0.0f, 0.0f);
}

// Called when the game starts or when spawned
void AAnimatedActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AAnimatedActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

}

