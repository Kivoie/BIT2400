// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"
#include "SimpleActor.h"



// Sets default values
ASimpleActor::ASimpleActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//new code
	RunningTime = 0;
	MaxMove = 20;
	shapes[0] = ConstructorHelpers::FObjectFinder<UPaperSprite>(TEXT("/Game/Sprites/enemy1_Sprite")).Object;
	shapes[1] = ConstructorHelpers::FObjectFinder<UPaperSprite>(TEXT("/Game/Sprites/enemy2_Sprite")).Object;
	currentShape = 0;
	numShapes = 2;
}

// Called when the game starts or when spawned
void ASimpleActor::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ASimpleActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	FVector NewLocation = GetActorLocation();
	float DeltaHeight = (FMath::Sin(RunningTime + DeltaTime) - FMath::Sin(RunningTime));
	NewLocation.Z += DeltaHeight * MaxMove;       //Scale our height by a factor of 20
	RunningTime += DeltaTime;
	SetActorLocation(NewLocation);
}

void ASimpleActor::ChangeShape()
{
	currentShape++;
	if (currentShape >= numShapes)
		currentShape = 0;
	ChangeShape(currentShape);
}
void ASimpleActor::ChangeShape(int s)
{
	if (s >= 0 && s < numShapes)
	{
		currentShape = s;
		UPaperSpriteComponent* spriteComponent = (UPaperSpriteComponent*)GetComponentByClass(UPaperSpriteComponent::StaticClass());
		spriteComponent->SetSprite(shapes[s]);
	}
}