// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SimpleGame2D, "SimpleGame2D" );
