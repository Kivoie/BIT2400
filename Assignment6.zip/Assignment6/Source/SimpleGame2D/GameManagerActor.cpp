// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"
#include "GameManagerActor.h"


// Sets default values
AGameManagerActor::AGameManagerActor()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void AGameManagerActor::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void AGameManagerActor::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	//player->Move_XAxis(1);
	if (player->GetActorLocation().X < -250)
	{
		//move enemy
		FVector NewLocation = enemy1->GetActorLocation();
		NewLocation.X += 1;
		enemy1->SetActorLocation(NewLocation);

		//change enemy shape
		if(enemy1->currentShape != 1)
			enemy1->ChangeShape(1);
	}
	else
	{
		if(enemy1->currentShape != 0)
			enemy1->ChangeShape(0);
	}
}

