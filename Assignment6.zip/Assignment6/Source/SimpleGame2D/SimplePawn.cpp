// Fill out your copyright notice in the Description page of Project Settings.

#include "SimpleGame2D.h"
#include "SimplePawn.h"


// Sets default values
ASimplePawn::ASimplePawn()
{
 	// Set this pawn to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	//new code
	// Set this pawn to be controlled by the lowest-numbered player
	//AutoPossessPlayer = EAutoReceiveInput::Player0;

}

// Called when the game starts or when spawned
void ASimplePawn::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ASimplePawn::Tick( float DeltaTime )
{
	Super::Tick( DeltaTime );

	//new code
	if (!CurrentVelocity.IsZero())
	{
		//move pawn
		FVector NewLocation = GetActorLocation() + (CurrentVelocity * DeltaTime);
		SetActorLocation(NewLocation);
		//move camera
		NewLocation = camera->GetActorLocation();
		NewLocation += (CurrentVelocity * DeltaTime);
		camera->SetActorLocation(NewLocation);
	}
}

// Called to bind functionality to input
void ASimplePawn::SetupPlayerInputComponent(class UInputComponent* InputComponent)
{
	Super::SetupPlayerInputComponent(InputComponent);

	//new code
	InputComponent->BindAxis("MoveX", this, &ASimplePawn::Move_XAxis);
}

//new code
void ASimplePawn::Move_XAxis(float AxisValue)
{
	// Move at 100 units per second forward or backward
	CurrentVelocity.X = FMath::Clamp(AxisValue, -1.0f, 1.0f) * 100.0f;

	//access Actor from Pawn
	if (AxisValue > 0)
		a->MaxMove = 20;
	if (AxisValue < 0)
		a->MaxMove = 5;
}